#!/bin/sh

autoreconf --verbose --install --force
