#!/bin/bash

etags $(find src/ -name "*.h")